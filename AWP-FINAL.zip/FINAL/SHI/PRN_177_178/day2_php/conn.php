<?php
$servername="localhost";
$username="root";
$password="actscdac";

$conn=new mysqli($servername,$username,$password);
if($conn->connect_error)
{
    die("Connection Failed: ".$conn->connect_error);
}
echo "Connected successfully"."<br>";

$sql="Create database php_Data";
if($conn->query($sql)===TRUE)
{
    echo "database created successfully";

}else{
    echo "Error creating database".$conn->error;
}

$conn->close();
?>