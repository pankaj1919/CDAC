<?php
$servername="localhost";
$username="root";
$password="actscdac";
$dbname="php_Data";

$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error)
{
    die("Connection Failed: ".$conn->connect_error);
}

// $sql = "INSERT INTO student (firstname, lastname, email) VALUES('shikha','caurasia','hik@');";
// $sql .= "INSERT INTO student (firstname, lastname, email) VALUES('shekhar','pawar','shek@');";
// $sql .= "INSERT INTO student (firstname, lastname, email) VALUES('sakshi','bhure','bhure@');";



// if($conn->multi_query($sql)== TRUE)
// {
//     $last_id=$conn->insert_id;
//     echo "record inserted, last id " . $last_id;
// }
// else
// {
//     echo "Error" . $sql ."<br>" .$conn->error;
// }

$stmt = $conn->prepare("INSERT INTO student (firstname, lastname, email) VALUES(?,?,?)");
$stmt->bind_param("sss",$firstname,$lastname,$email);

$firstname="Pankaj";
$lastname="Sakhare";
$email="pankaj@";
$stmt->execute();

$firstname="Durga";
$lastname="Sawant";
$email="durga@";
$stmt->execute();

$firstname="Shailesh";
$lastname="pata nahi";
$email="shail@";
$stmt->execute();


$stmt->close();
$conn->close();
?>