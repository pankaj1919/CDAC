<html>
    <head>

    </head>
<body>
<?php 

     $nameErr=$emailErr=$genderErr=$addressErr="";
$name = $email =  $address = $gender = $comment = $address = "";

if($_SERVER["REQUEST_METHOD"]=="POST")
{
    if(empty($_POST["name"]))
    {
        $nameErr="Name is Required";
    }
    else{
        $name = test_input($_POST["name"]);
    }

    if(empty($_POST["email"]))
    {
        $emailErr="Email is Required";
    }
    else{
        $email = test_input($_POST["email"]);
    }

    if(empty($_POST["gender"]))
    {
        $genderErr="Gender is Required";
    }
    else{
        $gender = test_input($_POST["gender"]);
    }

    if(empty($_POST["address"]))
    {
        $addressErr="Address is Required";
    }
    else{
        $address = test_input($_POST["address"]);
    }

    if(empty($_POST["comment"]))
    {
        $comment="";
    }
    else{
        $comment = test_input($_POST["comment"]);
    }
   
}
function test_input($data){
$data = trim($data);
$data = stripslashes($data);
$data = htmlspecialchars($data);
return $data;
}
?>
<?php
if(empty($name)||empty($email)||empty($address)||empty($gender)||empty($comment))
{
include 'form.html';
}
else {

echo "<h2> Your Input : </h2>";
echo $name;
echo "<br>";

echo $email;
echo "<br>";
echo $address;
echo "<br>";
echo $gender;
echo "<br>";
echo $comment;
echo "<br>";


}
?>
</body>
</html>