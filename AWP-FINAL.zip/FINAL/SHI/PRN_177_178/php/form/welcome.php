<html>
    <body>
        Welcome <?php
        
        echo $_POST["name"]; ?><br>
        Your Email : <?php echo $_POST["email"]; ?>
    </body>
</html>