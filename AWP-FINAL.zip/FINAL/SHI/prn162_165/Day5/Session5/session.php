<?php
    session_start();
    $cookie = "area_of_interests";
    $cookievalue = ["E-Commerce", "Education", "Social-Media"];
    setcookie($cookie, json_encode($cookievalue), time()+90, "/");
?>

<html>
    <head>
        <title>Sessions & Cookies in PHP</title>
    </head>
    <body>
        <?php
            $_SESSION["User"] = "SAKET";
            echo "Session variables initialized"."<br><br>";
            echo "Session variables are : ".$_SESSION["User"]."<br><br>";
            echo "Setting cookies...";
            if(isset($_COOKIE[$cookie])){
                echo "Cookies are set..!!";
            }
            echo "<br><br>";
            $cookiedata = json_decode($_COOKIE[$cookie], true);
            echo "Cookie values : <br> Area of Interests : ";
            echo "<ul>";
            foreach($cookiedata as &$value){
                echo "<li>"."$value";
            }
        ?>
    </body>
</html>