<?php
    $conn = new mysqli("localhost", "root", "actscdac", "php_sql");
    if($conn->connect_error){
        die("Connection failed");
    }
    else{
        echo "Connected to mysql..!!<br><br>";
    }
    
    // if($conn->query("CREATE DATABASE php_sql") === TRUE){
    //     echo "Database created successfully..!!<br><br>";
    // }
    // else{
    //     echo "error ".$conn->error;
    // }
   
    // if($conn->query("create table details(name varchar(20), email varchar(50))")){
    //     echo "table created.!!";
    // }
    // else{
    //     echo "error ".$conn->error;
    // }

    $uname =  $_GET['name'];
    $uemail = $_GET['email'];
    $sql = "insert into details (name, email) values('$uname','$uemail')";
    // echo "$uname"."<br>"."$uemail";
    if($conn->query($sql) === TRUE){
        echo "records inserted successfully..!!";
    }
    else{
        echo "Something went wrong : ".$conn->error;
    }
?>