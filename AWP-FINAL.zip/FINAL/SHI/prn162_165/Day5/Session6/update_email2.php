<?php
    $conn = new mysqli("localhost", "root", "actscdac", "php_sql");

    $em = $_GET['email'];
    $nm = $_GET['name'];

    $sql = "update details set email='$em' where name='$nm'";

    if($conn->query($sql) === TRUE){
        echo "Record Updated..!!";
        echo "<a href='index.html'>Home</a>";
    }
    else{
        echo "Error : ".$conn->error;
    }
?>