<?php
    for($i=1;$i<5;$i++){
        echo $i."<br>";
    }
    echo "<br>";
    $j=1;
    $s=1;
    
    while($j<=5){
        $s*=2;
        $j++;
        echo $s."<br>";
    }
    echo "<br><br><br>";
   
?>