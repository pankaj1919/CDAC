<?php
    $file = fopen("file.txt", "w");
    $content = $_GET['filecontent'];
    fwrite($file, $content);
    echo "File Successfully Written..!!<br>";
    echo "<a href='index.html'>Back to Home</a>";
    fclose($file);
?>