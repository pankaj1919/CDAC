<?php
include("process/dbconnect.php");
?>
<!DOCTYPE html>
<html>

<head>
    <title>Online Movie Booking - BookMyShow</title>
    <script src="js/jquery-3.4.1.js"></script>
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="form-group">
        <h1 class="form-heading">Online Movie Booking Form</h1>
        <div class="form-content">
            <table border="1" style="width:100%">
                <tr>
                    <td>ID</td>
                    <td>Name</td>
                    <td>Price</td>
                    <td>Release Date</td>
                    <td>Option</td>
                </tr>
                <?php
                $movies = "SELECT * FROM movies ORDER BY releaseDate desc LIMIT 10";
                $movie = mysqli_query($connect, $movies) or die(mysqli_error($connect));
                $var = 1;
                while ($row = mysqli_fetch_array($movie)) {
                    echo '
                        <tr>
                            <td>' . $var . '</td>
                            <td>' . $row['movie'] . '</td>
                            <td>' . $row['price'] . '</td>
                            <td>' . $row['releaseDate'] . '</td>
                            <td><a href="booking.php?id=' . $row['id'] . '">Book Now</a></td>   
                        </tr>                             
                        ';
                    $var = $var + 1;
                }
                ?>
            </table>
        </div>
    </div>

    <script src="js/script.js"></script>
</body>

</html>