<!DOCTYPE html>
<?php
    include("process/dbconnect.php");
?>
<html>
    <head>
        <title>Online Movie Booking - BookMyShow</title>
        <script src="js/jquery-3.4.1.js"></script>
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
        <div class="form-group">
            <h1 class="form-heading">Online Movie Booking Form</h1>
            <div class="form-content">
                <form class="main-form">
                    
                    <?php
                        if(!empty($_GET['id']))
                        {
                            $res=mysqli_query($connect,"SELECT * FROM movies WHERE id=".$_GET['id']);
                            $product=mysqli_fetch_array($res);
                            $movie = $product['movie'];
                            $price = $product['price'];
                            $release = $product['releaseDate'];
                        }
                    ?>
                    <div class="form-item">
                        <label>Movie Name</label> 
                        <input type="text" placeholder="Enter Movie Name" id="movieName" value="<?php echo $movie ?>" name="movieName" required readonly>
                    </div>

                    <div class="form-item">
                        <label>Movie Price</label>
                        <input type="number" placeholder="Enter Movie Ticket Price" value="<?php echo $price ?>" id="moviePrice" name="moviePrice" required readonly>
                    </div>

                    <div class="form-item">
                        <label>Release Date</label>
                        <input type="date" id="releaseDate" name="releaseDate" value="<?php echo $release ?>" required readonly>
                    </div>

                    <div class="form-item">
                        <label>Booking Date</label>
                        <input type="date" id="bookingDate" name="bookingDate" required>
                    </div>

                    <div class="form-item">
                        <input type="button" id="submit" name="submit" value="Book Movie">
                    </div>

                </form> 
            </div>
        </div>

        <script src="js/script.js"></script>
    </body>
</html>