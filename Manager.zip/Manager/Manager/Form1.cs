﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using BOL;
namespace Manager
{
    public partial class Form1 : Form
    {
        private List<Customer> customers = new List<Customer>();
        SaveFileDialog dlg;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void OnFileOpen(object sender, EventArgs e)
        {
            //Deserialization
            OpenFileDialog dlg = new OpenFileDialog();
            if(dlg.ShowDialog()== DialogResult.OK)
            {
                string filename = dlg.FileName;
                FileStream fs = new FileStream(filename,FileMode.Open);
                BinaryFormatter bf = new BinaryFormatter();
                customers = bf.Deserialize(fs) as List<Customer>;
                fs.Close();
                this.dataGridView1.DataSource = customers;
                
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //serialization

            dlg = new SaveFileDialog();
            if(dlg.ShowDialog() == DialogResult.OK)
            {
                string filename = dlg.FileName;
                FileStream fs = new FileStream(filename, FileMode.OpenOrCreate);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, customers);
                fs.Close();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void mnuRefresh_Click(object sender, EventArgs e)
        {
            this.dataGridView1.DataSource = null;
            this.dataGridView1.DataSource = customers;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (this.txtFirstName.Text == "" || this.txtLastName.Text == "")
            {
                MessageBox.Show("Please Enter Name");
            }

            else
            {

                string firstName = this.txtFirstName.Text;
                string lastName = this.txtLastName.Text;
                string contactNumber = this.txtContactNumber.Text;
                DateTime birthDate = this.dateBirthDate.Value;

                Customer cst = new Customer
                {
                    FirstName = firstName,
                    LastName = lastName,
                    ContactNumber = contactNumber,
                    BirthDate = birthDate
                };

                this.customers.Add(cst);
                this.dataGridView1.DataSource = null;
                this.dataGridView1.DataSource = customers;
            }
        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {

        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            
            if (dlg.FileName != null)
            {
                string filename = dlg.FileName;
                FileStream fs = new FileStream(filename, FileMode.Append);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, customers);
                fs.Close();
            }
            else
            {
                MessageBox.Show("file is not opened");
            }
        }
    }
}
